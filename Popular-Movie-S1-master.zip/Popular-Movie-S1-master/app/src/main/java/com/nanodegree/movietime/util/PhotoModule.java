package com.nanodegree.movietime.util;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by ali19 on 2/20/2018.
 */

@GlideModule
public final class PhotoModule extends AppGlideModule {

}
